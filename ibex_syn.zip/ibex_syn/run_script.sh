#!/bin/bash

mkdir -p out


surelog rtl/*.sv -DSYNTHESIS=1 -writepp -parse -verbose -d lib -d inst -d ast -d uhdm -d coveruhdm -elabuhdm -fileunit

YOSYS=/mnt/d/gradstuff/analograils/synlig/out/current/bin/yosys
export MODEL=ibex
export TOP=ibex_top

echo "Synthesizing $MODEL"

$YOSYS execute_sv_files.tcl