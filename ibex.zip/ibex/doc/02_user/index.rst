Ibex User Guide
===============

The Ibex User Guide provides all necessary information to use Ibex.
It is aimed at hardware developers integrating Ibex into a design, and software developers writing software running on Ibex.

.. toctree::
   :maxdepth: 1
   :caption: In this section

   system_requirements
   getting_started
   configuration
   integration
   examples
