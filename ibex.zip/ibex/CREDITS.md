Credits
=======

Ibex has originally been developed by the PULP team at ETH Zürich and
University of Bologna under the name Zero-riscy. In December 2018, Ibex has
been contributed to lowRISC who is maintaining and advancing the design since
then.

Throughout the years, Ibex has seen contributions from many people and we at
lowRISC are very thankful for all of them. This file lists the many people who
contributed to what is called Ibex today. If you made a contribution to Ibex
in the form of source code, bug reports, testing, marketing, or any other form,
please feel free to open a pull request to get your name added to this file.

- Alex Bradbury
- Andreas Kurth
- Andreas Traber
- Antonio Pullini
- Bryan Cantrill
- Canberk Topal
- Cathal Minnock
- Daniel Mlynek
- Dawid Zimonczyk
- Eunchan Kim
- Felix Yan
- Flavian Solt
- Florian Zaruba
- Francesco Conti
- Gary Guo
- Germain Haugou
- Greg Chadwick
- Harry Callahan
- Hai Hoang Dang
- Henner Zeller
- Hodjat Asghari Esfeden
- Igor Loi
- Ioannis Karageorgos
- Ivan Ribeiro
- Karol Gugala
- Leon Woestenberg
- Luís Marques
- Marek Pikuła
- Markus Wegmann
- Marno van der Maas
- Matthias Baer
- Mehmet Burak Aykenar
- Michael Gautschi
- Michael Gielda
- Michael Munday
- Michael Platzer
- Michael Schaffner
- Nils Graf
- Noah Huesser
- Noam Gallmann
- Pasquale Davide Schiavone
- Paul O'Keeffe
- Philipp Wagner
- Pirmin Vogel
- Prajwala Puttappa
- Rahul Behl
- Rhys Thomas
- Renzo Andri
- Robert Schilling
- Rupert Swarbick
- Sam Elliott
- Scott Johnson
- Stefan Mach
- Stefan Tauner
- Stefan Wallentowitz
- Sven Stucki
- Tao Liu
- Tobias Wölfel
- Tom Roberts
- Tudor Timi
- Udi Jonnalagadda
- Vladimir Rozic
- Yuichi Sugiyama
- Yusef Karim
- Zachary Snow
- Zeeshan Rafique
