#!/bin/sh

export PKG_CONFIG_PATH=/tools/riscv-isa-sim/lib/pkgconfig:$PATH
